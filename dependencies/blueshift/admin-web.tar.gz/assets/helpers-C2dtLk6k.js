import{h as s}from"./index-CSb05Bq5.js";const e=s.share;export{e as s};
